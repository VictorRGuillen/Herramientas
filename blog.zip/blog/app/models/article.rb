class Article < ApplicationRecord
	belongs_to :user
	validates :title, :presence => true,length:{minimum:2},:uniqueness =>true
	validates :body, :presence => true
end
