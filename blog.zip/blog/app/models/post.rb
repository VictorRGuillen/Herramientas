class Post < ApplicationRecord
end
