#ArticlesController.rb
class ArticlesController <ApplicationController
def index
	@articles = Article.all
end
def show
	@articles = Article.find(params[:id])
end
def new
	@articles = Article.new
end

def create
	@articles = current_user.articles.new(title: params[:article][:title], body: params[:article][:body])
	if  @articles.save
	redirect_to @articles
	else
		render:new
	end
end

def edit
	@articles = Article.find(params[:id])
	end

def update
	@articles = Article.find(params[:id])
	if @articles.update(articles_params)
		redirect_to @articles
	else
		render:edit
	
end
end
private def articles_params
	params.require(:article).permit(:title,:body)
end
end
