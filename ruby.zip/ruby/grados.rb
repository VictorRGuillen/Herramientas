puts "ingrese grados centigrados" 
x=gets.to_i

def grados(x=0)
return x*1.8 + 32
end

puts grados(x)