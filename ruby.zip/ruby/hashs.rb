#hashs.rb
h={"nombre"=> "Naruto", "rango"=>"Hokage","jutsu"=>"adwawfd"}
puts h
puts h["nombre"]
puts h["jutsu"]

h["aldea"]="konoha"
h["nombre"]="naruto uzumaki"
puts "Hashs: #{h}"

h.each do |key, value|
	puts "key : #{key}---value : #{value}"
end