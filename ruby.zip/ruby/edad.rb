puts "ingrese su edad"
edad=gets
edad=case edad.to_i
when 1..14 then "clasificacion A"
when 15..17 then "A y B"
when 18..20 then "A,B y C"
when 21..100 then "A,B,C y D"
end
puts edad
