class Persona
def initialize(nombre,edad)
@nombre = nombre
@edad = edad
end
def nombre
@nombre
end
#accesores de lectura
def nombre=(nombre)
@nombre=nombre
end
def edad
@edad
end
def edad=(edad)
@edad=edad
end
end
#Accesores de escritura
def database_engine=(engine)
	return @database_engine=engine
end

def port=(port)
	return @port=port
end

p=Persona.new("ray",23)

puts p.nombre
puts p.edad
p.edad=23
puts "nueva edad: #{p.edad}"