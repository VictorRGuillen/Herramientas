
#def a(x,y)
#return x+y
#x= gets
#y=gets

#$h={}

#h={"valor1"=> "#{x}", "valor2"=>"#{y}"}
#puts h
#h.each do |key, value|
#	puts "key : #{key}---value : #{value}"
#end
#end

$h = {}

def add(key,value)
	$h[key]= value
end
puts add("name","naruto")
puts add("aldea","Konoha")
puts $h