x = Random.rand(1..7)
def ra(x)
return match.sqrt(x)
end
puts ra(x)