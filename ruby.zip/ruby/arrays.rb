#arrays.rb
name = ["kakaroto",90,"vegeta777",91,"weiss",1,100,250]
strings = []
integers =[]
name.each do|n|
if n.to_i !=0
integers.push(n)
else
strings.push(n)
end
end

integers.first
puts integers


