y.to_i=5
puts y