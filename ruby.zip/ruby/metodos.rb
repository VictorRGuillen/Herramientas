#metodos.rb
def suma(x,y)
return x+y
end
puts suma(y=94,x=90)