class Settings
def initialize(databe_engine,port,host)
@database_engine = database_engine
@port = port
@host =host
end
	def database_engine
		return @database_engine
	end
	def port
		return @port
	end

	def host
		return @host
	end

end
p=Settings.new("Postgres","5432","localhost")
puts p.database_engine
puts p.port
puts p.host
