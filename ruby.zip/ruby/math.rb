x=gets
def co(x)
	return Math.cos(x.to_i)
end

puts co(x)